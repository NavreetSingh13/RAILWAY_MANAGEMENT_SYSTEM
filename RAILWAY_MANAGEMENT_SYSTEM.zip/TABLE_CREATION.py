def TABLE_CREATION_RAILWAY_MANAGEMENT_SYSTEM():
    import mysql.connector
    mycon=mysql.connector.connect(host='localhost',user='root',password='#NAVREETSINGH#',database='railway')
    cursor=mycon.cursor()
    mycon.autocommit=True
    s1="create table RAILWAY_MANAGEMENT_SYSTEM(NAME varchar(100),PHONE_NO varchar(10)  primary key,AGE int(2),GENDER varchar(6),STARTING_POINT varchar(100),DESTINATION varchar(100),DATE varchar(20))"
    cursor.execute(s1)
TABLE_CREATION_RAILWAY_MANAGEMENT_SYSTEM()




def TABLE_CREATION_USER_DETAILS():
    import mysql.connector
    mycon=mysql.connector.connect(host='localhost',user='root',password='#NAVREETSINGH#',database='railway')
    cursor=mycon.cursor()
    mycon.autocommit=True
    s1="create table USER_DETAILS(FIRST_NAME varchar(100),LAST_NAME varchar(100),USER_NAME varchar(100) ,PASSWORD varchar(100) primary key,PHONE_NO varchar(10),GENDER varchar(6),DOB varchar(20),AGE varchar(4))"
    cursor.execute(s1)
TABLE_CREATION_USER_DETAILS()
