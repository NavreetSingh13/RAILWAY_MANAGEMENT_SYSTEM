def Connection():
    import mysql.connector
    mycon=mysql.connector.connect(host='localhost',user='root',password='#NAVREETSINGH#',database='railway')
    if mycon.is_connected():
        print("Successfully Connected")
Connection()
