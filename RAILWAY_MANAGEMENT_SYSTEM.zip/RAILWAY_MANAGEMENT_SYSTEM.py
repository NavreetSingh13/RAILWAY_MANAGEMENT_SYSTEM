def menu():
    print('1.YES')
    print('2.NO')
    ch=int(input('DO YOU WANT TO CONTINUE OR NOT:'))
    while ch==1:
        print('WELECOME TO ONLINE RAILWAY RESERVATION SYSTEM')
        print('1.SIGN UP')
        print('2.SIGN IN')
        print('3.DELETE ACCOUNT')
        print('4.EXIT')
        ch1=int(input('ENTER YOUR CHOICE:'))
        if ch1==1:
            a=checking_1()
            if a==True:
                main()
            else:
                continue
        elif ch1==2:
            a=checking_2()
            if a==True:
                main()
            else:
                print('PASSWORD ALREADY EXISTS')
                continue
        elif ch1==3:
            a=checking_3()
            if a==True:
                print('ACCOUNT DELETED')
                continue
            elif a==False:
                print('YOUR PASSWAORD OR USERNAME IS INCORRECT')
                continue
        elif ch1==4:
            print('THANK YOU')
            break
        else:
                print('ERROR 404:PAGE NOT FOUND')
                break
def main():        
    print('1.YES')
    print('2.NO')
    ch=int(input("DO YOU WANT TO CONTINUE OR NOT:"))
    while ch==1:
           print(' 1.TICKET BOOKING',"\n", '2.TICKET CHECKING',"\n",'3.TICKET CANCELLING'"\n",'4.ACCOUNT DETAILS',"\n",'5.LOG OUT')
           ch=int(input('ENTER YOUR CHOICE:'))
           if ch==1:
               ticket_booking()
           elif ch==2:
               ticket_checking()
           elif ch==3:
               ticket_cancelling()
           elif ch==4:
               checking_4()
           elif ch==5:
               print('THANK YOU')
               break
           else:
               print('ERROR 404: ERROR PAGE NOT FOUND')

     
def ticket_booking():
    import mysql.connector
    mycon=mysql.connector.connect (host='localhost',user='root', password='#NAVREETSINGH#',database='railway')             
    cursor=mycon.cursor ()
    mycon.autocommit=True
    NAME=input('ENTER YOUR NAME:')
    PHONE_NO=input('ENTER YOUR PHONE NUMBER:')
    AGE=int(input('ENTER YOUR AGE:'))
    print(' M=MALE','\n','F=FEMALE','\n','N=NOT TO MENTION')
    GENDER=input('ENTER YOUR GENDER:')
    Gender=GENDER.upper()
    STARTING_POINT=input('ENTER YOUR STARTING POINT:')
    DESTINATION=input('ENTER YOUR DESTINATION:')
    date1=input('ENTER DATE(DD):')
    date2=input('ENTER MONTH(MM):')
    date3=input('ENTER YEAR(YYYY):')
    DATE=date1+"/"+date2+"/"+date3
    a={'M':'MALE','F':'FEMALE','N':'NOT TO MENTION'}
    s1="insert into RAILWAY_MANAGEMENT_SYSTEM values ('{}',{},{},'{}','{}','{}','{}')".format(NAME,PHONE_NO,AGE,GENDER,STARTING_POINT,DESTINATION,DATE)
    cursor.execute(s1)
    print('BOOKED SUCCESSFULLY')



def ticket_checking():
    import mysql.connector
    mycon=mysql.connector.connect(host='localhost',user='root',password='#NAVREETSINGH#',database='railway')
    cursor=mycon.cursor()
    mycon.autocommit=True
    print('1.YES')
    print('2.NO')
    ch=int(input("DO YOU WANT TO CONTINUE OR NOT:"))
    if ch==1:
        PHONE_NO=int(input('ENTER YOUR PHONE NUMBER:'))
        try:
            s1="select * from RAILWAY_MANAGEMENT_SYSTEM where PHONE_NO=PHONE_NO"
            cursor.execute(s1)
            data=cursor.fetchall()[0]
            Data=list(data)
            a=['NAME','PHONE_NUMBER','AGE','GENDER','STARTING_POINT','DESTINATION','DATE']                                                                  
            print(a[0],'>>>>',Data[0].upper())
            print(a[1],'>>>>',Data[1])
            print(a[2],'>>>>',Data[2])
            print(a[3],'>>>>',Data[3].upper())
            print(a[4],'>>>>',Data[4].upper())
            print(a[5],'>>>>',Data[5].upper())
            print(a[6],'>>>>',Data[6])
        except:
            print('TICKET DOES NOT EXISTS')
    elif ch==2:
        print('THANK YOU')
    else:
        print('ERROR 404:PAGE NOT FOUND')
    
       

def ticket_cancelling():
    import mysql.connector
    mycon=mysql.connector.connect(host='localhost',user='root',password='#NAVREETSINGH#',database='railway')
    cursor=mycon.cursor()
    mycon.autocommit=True
    print('1.YES')
    print('2.NO')
    ch=int(input("DO YOU WANT TO CONTINUE OR NOT:"))
    if ch==1:
        PHONE_NO=input('ENTER YOUR PHONE NUMBER:')
        s1="delete from RAILWAY_MANAGEMENT_SYSTEM where PHONE_NO=PHONE_NO"
        cursor.execute(s1)
        print('TICKET CANCELLED')
    elif ch==2:
        print('THANK YOU')
    else:
        print('ERROR 404:PAGE NOT FOUND')

def checking_1():
    import mysql.connector
    mycon=mysql.connector.connect(host='localhost',user='root',password='#NAVREETSINGH#',database='railway')
    cursor=mycon.cursor()
    mycon.autocommit=True
    FIRST_NAME=input("ENTER YOUR FIRST NAME:")
    LAST_NAME=input("ENTER YOUR LAST NAME:")
    USER_NAME=input('ENTER YOUR USERNAME:')
    PASSWORD=input('ENTER YOUR PASSWORD:')
    PASSWORD1=input('RE-ENTER YOUR PASSWORD:')
    PHONE_NO=input("ENTER YOUR PHONE NUMBER:")
    print(' M=MALE','\n','F=FEMALE','\n','N=NOT TO MENTION')
    GENDER=input('ENTER YOUR GENDER:')
    print("ENTER YOUR DATE OF BIRTH")
    d=input("ENTER DATE(DD):")
    o=input("ENTER MONTH(MM):")
    b=input("ENTER YEAR(YYYY):")
    DOB=d+'/'+o+'/'+b
    AGE=input('ENTER YOUR AGE:')
    if PASSWORD==PASSWORD1:
        c1="insert into USER_DETAILS values('{}','{}','{}','{}',{},'{}','{}',{})".format(FIRST_NAME,LAST_NAME,USER_NAME,PASSWORD,PHONE_NO,GENDER,DOB,AGE)
        cursor.execute(c1)
        print('WELCOME',FIRST_NAME,LAST_NAME)
        return True

    else:
        print('BOTH PASSWORDS ARE NOT MATCHING')

def checking_2():
    import mysql.connector
    mycon=mysql.connector.connect(host='localhost',user='root',password='#NAVREETSINGH#',database='railway')
    cursor=mycon.cursor()
    mycon.autocommit=True
    a=input('ENTER YOUR USERNAME:')
    b=input('ENTER YOUR PASSWORD:')
    try:
        s1="select USER_NAME from USER_DETAILS where PASSWORD='{}'".format(b)
        c1="select FIRST_NAME,LAST_NAME from USER_DETAILS where PASSWORD='{}'".format(b)
        cursor.execute(c1)
        data1=cursor.fetchall()[0]
        data1=list(data1)
        data1=data1[0]+' '+data1[1]
        cursor.execute(s1)
        data=cursor.fetchall()[0]
        data=list(data)[0]
        if data==a:
            print('HII!!',data1)
            return True
        else:
            return False
    except:
        print('ACCOUNT DOES NOT EXIST')
        
        
def checking_3():
    import mysql.connector
    mycon=mysql.connector.connect(host='localhost',user='root',password='#NAVREETSINGH#',database='railway')
    cursor=mycon.cursor()
    mycon.autocommit=True
    a=input('ENTER YOUR USERNAME:')
    b=input('ENTER YOUR PASSWORD:')
    try:
        s1="select USER_NAME from USER_DETAILS where PASSWORD='{}'".format(b)
        cursor.execute(s1)
        data=cursor.fetchall()[0]
        data=list(data)
        if data[0]==a:
             print('IS THIS YOUR ACCOUNT?')
             s1="select USER_NAME from USER_DETAILS where PASSWORD='{}'".format(b)
             c1="select FIRST_NAME,LAST_NAME from USER_DETAILS where PASSWORD='{}'".format(b)
             cursor.execute(c1)
             data1=cursor.fetchall()[0]
             data1=list(data1)
             data1=data1[0]+' '+data1[1]
             cursor.execute(s1)
             data=cursor.fetchall()[0]
             data=list(data)
             if data[0]==a:
                 x=['FIRST_NAME','LAST_NAME','PHONE_NO','GENDER','DOB','AGE']
                 s1="select FIRST_NAME,LAST_NAME,PHONE_NO,GENDER,DOB,AGE from USER_DETAILS where PASSWORD='{}'".format(b)
                 cursor.execute(s1)
                 data=cursor.fetchall()[0]
                 data=list(data)
                 print(x[0],':',data[0])
                 print(x[1],':',data[1])
                 print(x[2],':',data[2])
                 print(x[3],':',data[3])
                 print(x[4],':',data[4])
                 print(x[5],':',data[5])
                 print('1.YES')
                 print('2.NO')
                 vi=int(input('ENTER YOUR CHOICE:'))
                 if vi==1:
                     b1="delete from USER_DETAILS where PASSWORD='{}'".format(b)
                     cursor.execute(b1)
                     return True
                 elif vi==2:
                     print('SORRY!! RETRY')
                 else:
                     print('ERROR 404:PAGE NOT FOUND')
        else:
            return False
    except:
        print('ACCOUNT DOES NOT EXIST')
        

def checking_4():
    import mysql.connector
    mycon=mysql.connector.connect(host='localhost',user='root',password='#NAVREETSINGH#',database='railway')
    cursor=mycon.cursor()
    mycon.autocommit=True
    a=input('ENTER YOUR USERNAME:')
    b=input('ENTER YOUR PASSWORD:')
    try:
        s1="select USER_NAME from USER_DETAILS where PASSWORD='{}'".format(b)
        c1="select FIRST_NAME,LAST_NAME from USER_DETAILS where PASSWORD='{}'".format(b)
        cursor.execute(c1)
        data1=cursor.fetchall()[0]
        data1=list(data1)
        data1=data1[0]+' '+data1[1]
        cursor.execute(s1)
        data=cursor.fetchall()[0]
        data=list(data)
        if data[0]==a:
            
            x=['FIRST_NAME','LAST_NAME','PHONE_NO','GENDER','DOB','AGE']
            s1="select FIRST_NAME,LAST_NAME,PHONE_NO,GENDER,DOB,AGE from USER_DETAILS where PASSWORD='{}'".format(b)
            cursor.execute(s1)
            data=cursor.fetchall()[0]
            data=list(data)
            print(x[0],':',data[0])
            print(x[1],':',data[1])
            print(x[2],':',data[2])
            print(x[3],':',data[3])
            print(x[4],':',data[4])
            print(x[5],':',data[5])
            
            
        else:
            return False
    except:
        print('ACCOUNT DOES NOT EXIST')

menu()
